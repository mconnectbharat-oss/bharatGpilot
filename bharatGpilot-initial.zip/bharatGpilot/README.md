# BharatGpilot

Initial Next.js foundation with a server-side OpenRouter gateway.

## Setup
1. Copy `.env.example` to `.env.local`.
2. Add a newly rotated OpenRouter API key to `OPENROUTER_API_KEY`.
3. Run `npm install` then `npm run dev`.

Never expose the API key through `NEXT_PUBLIC_*` or commit `.env.local`.

## API
POST `/api/chat` with `{ "messages": [{ "role": "user", "content": "Hello" }] }`.
